 <html>
<head>
    
    <title> HOME Page</title>
</head>

 
    
        <table width='100%' >
            <tr>
             
                <td align='right'>
                    <nav>
                        <a href='../others/HomePage.php'>Home</a> |
                        <a href=' ./login.php'>Log In</a> |
                        <a href=' ./registration.php'>Registration</a>
                    </nav>
                </td>
            </tr>
        </table>
   
       
 <div class="container">
			<div class="welcome_text"> <h2> Welcome to   University web site </h2> </div>
			 <img src="images/i1.jpg" width=100%>
		</div>
      
    
   
</body>
</html>