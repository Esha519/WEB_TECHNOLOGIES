

<html>


<head>
	<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
	<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="about.css">
</head>

<body>


<div class="about">
<h1><a href="General.php">General Information</a><br></a></h1> 
<br>
<br>
<br>




<h1><a href="Why.php">Why Study at UE</a><br></a></h1> 

<br><br><br>

<h1><a href="Rules.php">Rule_Of_Entry</a><br></a></h1> 


<br><br><br>


<h1><a href="Resource.php">Resource</a><br></a></h1> 
<br><br><br><br><br>

</div>
<div class="to">
<a href="HomePage.php">Go To HomePage</a></div>
</body>
</html>