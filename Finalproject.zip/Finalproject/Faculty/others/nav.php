 <ul>
       

         <table border = "15" align="center" >

             

            <tr>
                <td> <h1>  <a href="addStudent.php">Add Student in section O </a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="showAllStudents.php"> Show all students in Section O</a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="searchUser.php">Search Students In Section O </a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="faclog2nd.php">Go To Previous Page </a>  </h1> </td>
            </tr> 
        
       
        
    </ul>