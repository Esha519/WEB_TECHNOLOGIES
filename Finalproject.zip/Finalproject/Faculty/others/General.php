<!DOCTYPE html>
<html lang="en">
<head>
<title>Genaral Information</title>

<link rel="stylesheet" type="text/css" href="about.css">
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<body>
	<div class="eu">
<h4 > EU currently operates under four distinct Faculties:</h4></div>

<p  style="color:red;">
Faculty of Arts and Social Sciences (FASS)</p><br><br>



<p  style="color:green;">Faculty of Business Administration (FBA)</p>
<br><br>

<p  style="color:yellow;">Faculty of Engineering (FE)</p><br>

<p  style="color:blue;">Faculty of Science And Technology (FST)</p>

<br><br>


<p  style="color:red;">
Faculty of Arts and Social Sciences (FASS)</p><br>
<p>
Undergraduate Programs:
Bachelor of Arts (BA) in Media and Mass Communication
Bachelor of Arts (BA) in English
Bachelor of Law (LLB)
Bachelor of Social Science (BSS) in Economics
Graduate Programs:
Masters in Development Studies (MDS)
Masters in Public Health (MPH)

	</p>

<br><br>



<p  style="color:green;">
Faculty of   Business Administration (FBA) </p><br>
<p>
Undergraduate Program: 

Bachelor of Business Administration (BBA) Major in-
Accounting
Economics
Finance
Human Resource Management (HRM)
International Business (IB)
Investment Management (IM)
Management
Management Information Systems (MIS)
Marketing
Operations and Supply Chain Management (OSCM)
Tourism and Hospitality Management (THM)
Graduate Program: 

Master of Business Administration (MBA) Major in-
Accounting
Agribusiness
Business Economics
Finance
Human Resource Management (HRM)
Management
Management Information Systems (MIS)
Marketing
Operations and Supply Chain Management (OSCM)
Tourism and Hospitality Management (THM)
Executive Master of Business Administration (EMBA)
 
	
	</p>




<p  style="color:yellow;">
Faculty of Engineering  (FE) </p><br>
<p>
Undergraduate Programs:

Bachelor of Architecture (BArch)
Bachelor of Science (BSc) in Electrical and Electronic Engineering (EEE)
Bachelor of Science (BSc) in Industrial and Production Engineering (IPE)
Graduate Programs:

Master of Engineering in Electrical and Electronic Engineering (MEEE)
Master of Engineering in Telecommunications Engineering (MTEL)


</p>
<p  style="color:blue;">
Faculty of Science and Technology (FST)</p><br>
<p>Undergraduate Program:

Bachelor of Science (BSc) in Computer Science and Engineering (CSE)
Graduate Program:

Master of Science in Computer Science (MSCS)</p>
<h3>Organization</h3>
<p>The academic supervision and control of the University is the responsibility of the Vice Chancellor. The Vice Chancellor is assisted by the Academic Council and an Advisory Committee of which the Vice Chancellor is the Chairperson. All matters concerning admission, candidacy and comprehensive examinations or modifications of programs, academic issues and concerns are submitted in writing to the Office of the Vice Chancellor for approval. Decisions of the Vice Chancellor are final.</p>

<br><br>
<div class="or">
<a href="aboutus.php">Go" About us "Page<a href="HomePage.php">Go To HomePage </a></a></div>
</body>
</head>
</html>