<!DOCTYPE html>
<html lang="en">
<head>
<title>View Profile</title>

<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">


</head>
<body >

<img src="esha.jfif" width="150" height="160">
<h4>Name :   Nura Solahin Esha  </h4>
<h4> Email : nooresha87@gmail.com</h4>
<h4> Phone No  : 0179373654</h4>
<h4>Present Address : Green Road, Dhaka</h4>
<h4>Permanent address : Manikgonj</h4>
<h4>Date of Birth : 03/08/1990</h4>
<br>
<a href="facprofile.php"> Change Profile </a><br><br>
<a href="facultyforgot.php"> Change Password </a><br><br>
<a href="HomePage.php"> Log out </a><br><br>
<a href="faclog2nd.php"> Go Back To Dashboard </a>
</body>

</html>












</body>
</html>