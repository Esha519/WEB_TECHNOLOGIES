 <ul>
       

         <table border = "15" align="center" >

             

            <tr>
                <td> <h1 >  <a href="Ballinfo.html">All Student in section B </a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="data.php"> Show all students in Section B (d)</a>  </h1> </td>
            </tr> 
             <tr>
                <td> <h1>  <a href="sectionB.html">Search Students In Section B</a>  </h1> </td>
            </tr> 
             
        
         <tr>
                <td> <h1>  <a href="student.xml">Search Students In Section O </a>  </h1> </td>
            </tr> 
        
    </ul>