
<html>
<head>
	<title> success </title>
</head>
 
<body style="background-color:pink;">
 <fieldset>
	<table>

<b> <h1> file uploaded successfully  </h1> </b> <br>
<br> 
 
 
<tr>  
					<td></td>
					<td>
						 <br> 
						<h2> <a href="dashboard.php">  Dashboard</a> </h2>
		                
						
					</td>
				</tr>
				 
				</table>
	</fieldset>			
</body>
</html>