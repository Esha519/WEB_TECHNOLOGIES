  
<?php
	session_start();
	if(isset($_SESSION['flag']))
	{
?>
  
  
<?php
	$title= " home page";
	 
?>
   <fieldset>
        <table width='100%' >
            <tr>
                 
                <td align='right'>
                    <nav>
                        <a href='./home.php'>Home Page </a> ||
                         <a href='./signout.php'> Sign out </a>
						 
                    </nav>
                </td>
            </tr>
        </table>
    </fieldset>
    <fieldset>
        <table width='100%' >
            <tr>
              
                <td align='right'>
                    <nav>
                      <b> <label> Thank you <?php echo $_COOKIE['uname'] ?></a> </label> .Now your  Logged in   Portal </b>   
                       
                    </nav>
                </td>
            </tr>
        </table>
    </fieldset>
	 
    <table border="1px solid black" width='100%'>
        <tr>
            <td>
                <label> </label>
                <br>
				
				     <ul>
					 
					 	 
						 
						    <li><a href='./viewprofile.php'>View  User</a></li>
							 <li><a href='./addcourse.php'> Add Course </a></li>
							  <li><a href='./viewcourse.php'>View  Course</a></li>
							   
							    <li><a href='./dropcourse.php'>  Drop  Course</a></li>
								 
									  <li><a href='./borrowbook.php'> Borrow Book</a></li>
									    <li><a href='./borrowstatus.php'> Borrow Book Status</a></li>
										 <li><a href='./returnbook.php'>  Return Book</a></li>
										  <li><a href='./fileupload.php'>  Upload Document</a></li>
								 	  <li><a href='./mailbox.php'>  Mail Box</a></li>
						  </ul>
                <hr>
                
            </td>
            <td>
                 <h1> I'm <?php echo $_COOKIE['uname'] ?></h1> to logged in portal.
            </td>
        </tr>
    </table>
     
   
</body>
</html>

	 
<?php

	}else{
		header('location: login.php');
	}

?>