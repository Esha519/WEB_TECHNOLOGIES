  
<?php 
	$title= "profile page";
	 
?>
<fieldset>
<legend>
Add Your Image
</legend>

     
						 
						       <form action="registration.php" enctype="multipart/form-data" method="post">
                                 Add your  image :
                             <input type="file" name="file" placeholder ="choose an image">  <br><br/> 
                         <input type="submit" value="displsy" name="Submit1"> <br/>
					   
              

                </form>
 
 </fieldset>
 