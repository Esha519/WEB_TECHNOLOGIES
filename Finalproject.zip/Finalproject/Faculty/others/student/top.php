	 
	 
        <table width='100%' >
            <tr>
                 
                <td align='right'>
                    <nav>
					
					<a href='dashboard.php'>  Back</a>  
                         
                        <a href='signout.php'> sign  Out</a>  
                     
                    </nav>
                </td>
            </tr>
        </table> 