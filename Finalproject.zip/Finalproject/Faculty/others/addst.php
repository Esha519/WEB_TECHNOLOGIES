<!DOCTYPE HTML>
<html>  
<head>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<title>Application</title>
</head>
<h1 align='center'><i>Please choose your desire program</i> </h1>
<table align='center'>

<h2><i><a href="ApplicationFormUndergraduate.php">Undergraduation</i>
<br><br>


<br><br>
<i><a href="ApplicationFormGraduate.php">Postgraduation</a></i>
</h2><br><br><br>

<button><i><a href="HomePage.php">Go To HomePage</i> </button>

</html>