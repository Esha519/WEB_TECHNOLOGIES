<?php


require ('../db/userCRUD.php');

				if (isset($_POST['rbtn'])){

					$dirpath = "../assets/".$_FILES['profilepic']['name'];

					if (move_uploaded_file($_FILES['profilepic']['tmp_name'], $dirpath)) {

					$username 	 =   $_POST['username'];
					$userID 	 =   $_POST['userID'];
					$password 	 =   $_POST['password'];
					$designation =   $_POST['designation'];
					$gender      =   $_POST['gender'];
					$dob         =   $_POST['dob'];
					$number      =   $_POST['number'];
					$email       =   $_POST['email'];
					$address     =   $_POST['address'];
					$proPic      =   $dirpath;
					$userStatus  =   "deactive";

					$user = [

						'username'   => $username,
						'userID'     => $userID,
						'password'   => $password,
						'designation'=> $designation,
						'gender'     => $gender,
						'dob'        => $dob,
						'number'     => $number,
						'email'      => $email,
						'address'    => $address,
						'proPic'     => $proPic,
						'status'     => $userStatus
					];


					$result = insertUser ($user);

					if ($result){

						header('location: ../view/login.php?msg=dn');

					}
					}
					else{echo "error";}

					
				}

	

 ?>