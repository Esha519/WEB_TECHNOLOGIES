<?php 

session_start();

require ('../db/application.php');


		if (isset($_POST['appBtn'])){

			        

					$w_id 		 =   $_SESSION ['userID'];
					$subject 	 =   $_POST['appSub'];
					$body 	     =   $_POST['appBody'];
					$status      =   "Pending";

					if (empty($subject ) || empty($body)) {

						header('location: ../view/leaveapp.php?msg=empt');
						
					}else{

						$app = [

						'w_id'     => $w_id,
						'subject'  => $subject,
						'body'     => $body,
						'status'   => $status
					];

					
					$result = insertApp ($app);

					if ($result){

						header('location: ../view/leaveapp.php?msg=rg');

					}
					}
					
					}
					else{echo "error";}

 ?>