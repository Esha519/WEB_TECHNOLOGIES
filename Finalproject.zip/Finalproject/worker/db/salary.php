<?php 

	require_once('db.php');

	function getSalary (){

		    $uid = $_SESSION ['userID'];

		    $conn       =  getConnection();
		    $sql        =  "select * from salary where w_id= '$uid'";
		    $result     =  mysqli_query($conn, $sql);

		   $salaryList = [];

		   while($data = mysqli_fetch_assoc($result)){

		   	array_push($salaryList, $data);

		   }

		   return $salaryList;

	}


	 ?>