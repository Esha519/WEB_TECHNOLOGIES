<?php 

	require_once('db.php');


	function insertApp ($app){

			$connection =  getConnection();
       $sql = "insert into application values ('','{$app['w_id']}','{$app['subject']}','{$app['body']}','{$app['status']}')";
		$result 	=  mysqli_query($connection, $sql);

			if($result){

					return true;
			}
			else{
				return false;
			}
	}


	function getApp (){

		    $uid = $_SESSION ['userID'];

		    $conn       =  getConnection();
		    $sql        =  "select * from application where w_id= '$uid'";
		    $result     =  mysqli_query($conn, $sql);

		   $appList = [];

		   while($data = mysqli_fetch_assoc($result)){

		   	array_push($appList, $data);

		   }

		   return $appList;

	}

?>