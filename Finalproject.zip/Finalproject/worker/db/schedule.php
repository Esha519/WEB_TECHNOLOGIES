<?php 

	require_once('db.php');

	function getSchedule (){

		    $uid = $_SESSION ['userID'];

		    $conn       =  getConnection();
		    $sql        =  "select * from schedule where w_id= '$uid'";
		    $result     =  mysqli_query($conn, $sql);

		   $worklist = [];

		   while($data = mysqli_fetch_assoc($result)){

		   	array_push($worklist, $data);

		   }

		   return $worklist;

	}


	 ?>