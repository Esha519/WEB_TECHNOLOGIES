<?php 

	require('../php/check.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<form method='post' action="../php/logout.php">
		<center><h1>Welcome Home <?php echo $_SESSION ['uname']  ?> </h1>
		<button type="submit" name="lbtn">Log Out</button></center>
	</form>

</body>
</html>

