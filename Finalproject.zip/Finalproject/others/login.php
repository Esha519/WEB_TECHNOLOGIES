<!DOCTYPE HTML>
<html>  
<head>
<title>login</title>
<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="mobile.css">
<link rel="stylesheet" type="text/css" href="homepage.css">
</head>
<body>
<div class="welcome">
<h1 align='center'>WELCOME TO EU PORTAL</h1></div><br>
<div class="what">
<h2 align="center">What type of user are you!</h2></div><br>
<div class="log">
<a href="adminlogin.php">  Admin...



<a href="facultylog.php">  Faculty...


 <a href="../student/home.php">  Student



<a href= "../worker/index.html">  Worker...

<a href="HomePage.php">Go To HomePage
</b>
</div>
</a></a></a></a></a></body>
</html>